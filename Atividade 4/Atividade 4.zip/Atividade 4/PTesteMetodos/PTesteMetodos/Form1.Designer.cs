﻿namespace PTesteMetodos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exercicioF1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercicioF2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercicioF3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercicioF4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exercicioF5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fSairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editorDeTextoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculadoraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exercicioF1ToolStripMenuItem,
            this.exercicioF2ToolStripMenuItem,
            this.exercicioF3ToolStripMenuItem,
            this.exercicioF4ToolStripMenuItem,
            this.exercicioF5ToolStripMenuItem,
            this.fSairToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1364, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exercicioF1ToolStripMenuItem
            // 
            this.exercicioF1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copiarToolStripMenuItem,
            this.colarToolStripMenuItem});
            this.exercicioF1ToolStripMenuItem.Name = "exercicioF1ToolStripMenuItem";
            this.exercicioF1ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D1)));
            this.exercicioF1ToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.exercicioF1ToolStripMenuItem.Text = "Exercicio f1";
            // 
            // exercicioF2ToolStripMenuItem
            // 
            this.exercicioF2ToolStripMenuItem.Name = "exercicioF2ToolStripMenuItem";
            this.exercicioF2ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D2)));
            this.exercicioF2ToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.exercicioF2ToolStripMenuItem.Text = "Exercicio f2";
            this.exercicioF2ToolStripMenuItem.Click += new System.EventHandler(this.exercicioF2ToolStripMenuItem_Click);
            // 
            // exercicioF3ToolStripMenuItem
            // 
            this.exercicioF3ToolStripMenuItem.Name = "exercicioF3ToolStripMenuItem";
            this.exercicioF3ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D3)));
            this.exercicioF3ToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.exercicioF3ToolStripMenuItem.Text = "Exercicio f3";
            this.exercicioF3ToolStripMenuItem.Click += new System.EventHandler(this.exercicioF3ToolStripMenuItem_Click);
            // 
            // exercicioF4ToolStripMenuItem
            // 
            this.exercicioF4ToolStripMenuItem.Name = "exercicioF4ToolStripMenuItem";
            this.exercicioF4ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D4)));
            this.exercicioF4ToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.exercicioF4ToolStripMenuItem.Text = "Exercicio f4";
            // 
            // exercicioF5ToolStripMenuItem
            // 
            this.exercicioF5ToolStripMenuItem.Name = "exercicioF5ToolStripMenuItem";
            this.exercicioF5ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D5)));
            this.exercicioF5ToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.exercicioF5ToolStripMenuItem.Text = "Exercicio f5";
            // 
            // fSairToolStripMenuItem
            // 
            this.fSairToolStripMenuItem.Name = "fSairToolStripMenuItem";
            this.fSairToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.S)));
            this.fSairToolStripMenuItem.Size = new System.Drawing.Size(55, 24);
            this.fSairToolStripMenuItem.Text = "FSair";
            this.fSairToolStripMenuItem.Click += new System.EventHandler(this.fSairToolStripMenuItem_Click);
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.copiarToolStripMenuItem.Text = "Copiar";
            this.copiarToolStripMenuItem.Click += new System.EventHandler(this.copiarToolStripMenuItem_Click);
            // 
            // colarToolStripMenuItem
            // 
            this.colarToolStripMenuItem.Name = "colarToolStripMenuItem";
            this.colarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.colarToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.colarToolStripMenuItem.Text = "Colar";
            this.colarToolStripMenuItem.Click += new System.EventHandler(this.colarToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editorDeTextoToolStripMenuItem,
            this.calculadoraToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(180, 52);
            // 
            // editorDeTextoToolStripMenuItem
            // 
            this.editorDeTextoToolStripMenuItem.Name = "editorDeTextoToolStripMenuItem";
            this.editorDeTextoToolStripMenuItem.Size = new System.Drawing.Size(179, 24);
            this.editorDeTextoToolStripMenuItem.Text = "Editor de Texto";
            // 
            // calculadoraToolStripMenuItem
            // 
            this.calculadoraToolStripMenuItem.Name = "calculadoraToolStripMenuItem";
            this.calculadoraToolStripMenuItem.Size = new System.Drawing.Size(179, 24);
            this.calculadoraToolStripMenuItem.Text = "Calculadora";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1364, 639);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exercicioF1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercicioF2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercicioF3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercicioF4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exercicioF5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fSairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colarToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editorDeTextoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculadoraToolStripMenuItem;
    }
}

