﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        string palavra1, palavra2;

        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtPalavra1.Text, txtPalavra2.Text, StringComparison.OrdinalIgnoreCase) == 0)
            {
                MessageBox.Show("Os textos são iguais!");
            }
            else
            {
                MessageBox.Show("Os textos são diferentes!");
            }
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            palavra1 = txtPalavra1.Text;
            palavra2 = txtPalavra2.Text;

            txtPalavra2.Text = palavra2.Substring(0, palavra2.Length / 2) + palavra1 + palavra2.Substring(palavra2.Length / 2);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPalavra1.Clear();
            txtPalavra2.Clear();
            palavra1 = "";
            palavra2 = "";
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            palavra1 = txtPalavra1.Text;
            txtPalavra1.Text = palavra1.Insert(palavra1.Length / 2, "**");
        }
    }
}
