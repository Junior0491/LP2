﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        int num1, num2, numSorteado;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            num2 = 0;
            num1 = 0;
            numSorteado = 0;
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero1.Text, out num1) || (!int.TryParse(txtNumero2.Text, out num2)))
            {
                MessageBox.Show("Números inválidos!");
            }
            else
            {

                if (num1 < num2)
                {
                    Random rnd = new Random();
                    numSorteado = rnd.Next(num1, num2 + 1);

                    MessageBox.Show($"Número sorteado foi {numSorteado}");
                    MessageBox.Show($"O {num1} é menor que {num2}");
                }
                else if (num1 > num2)
                {
                    Random rnd = new Random();
                    numSorteado = rnd.Next(num2, num1 + 1);
                    MessageBox.Show($"Número sorteado foi {numSorteado}");
                    MessageBox.Show($"O {num1} é maior que {num2}");
                }
                else
                {
                    numSorteado = num1;
                    MessageBox.Show($"Número sorteado foi {numSorteado}");
                    MessageBox.Show($"O {num1} é igual {num2}");
                }
            }
        }

        public frmExercicio5()
        {
            InitializeComponent();
        }
    }
}
