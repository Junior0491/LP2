﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContnum_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contaNum = 0;

            while (posicao < rcrtxtFrase.Text.Length)
            {
                if (char.IsNumber(rcrtxtFrase.Text[posicao]))
                {
                    contaNum++;
                }

                posicao++;
            }
            MessageBox.Show($"a frase tem {contaNum} números");
        }

        private void btnLocaliza_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            for (int i = 0; i < rcrtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rcrtxtFrase.Text[i]))
                {
                    posicao = i + 1; 
                    break;
                }
            }
            if (posicao == 0)
            {
                MessageBox.Show("não há caracteres em branco na frase");
            }
            else
            {
                MessageBox.Show($"o 1º caracter em branco está na posição {posicao}");
            }
        }

        private void btnContaletra_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;

            foreach (char c in rcrtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"a frase tem {contaLetra} letras");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rcrtxtFrase.Clear();
        }
    }
}
