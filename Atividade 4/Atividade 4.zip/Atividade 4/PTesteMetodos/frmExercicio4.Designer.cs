﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rcrtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContnum = new System.Windows.Forms.Button();
            this.btnContaletra = new System.Windows.Forms.Button();
            this.btnLocaliza = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rcrtxtFrase
            // 
            this.rcrtxtFrase.Location = new System.Drawing.Point(248, 52);
            this.rcrtxtFrase.Name = "rcrtxtFrase";
            this.rcrtxtFrase.Size = new System.Drawing.Size(936, 331);
            this.rcrtxtFrase.TabIndex = 0;
            this.rcrtxtFrase.Text = "";
            // 
            // btnContnum
            // 
            this.btnContnum.Location = new System.Drawing.Point(248, 475);
            this.btnContnum.Name = "btnContnum";
            this.btnContnum.Size = new System.Drawing.Size(182, 124);
            this.btnContnum.TabIndex = 1;
            this.btnContnum.Text = "Conta Numero";
            this.btnContnum.UseVisualStyleBackColor = true;
            this.btnContnum.Click += new System.EventHandler(this.btnContnum_Click);
            // 
            // btnContaletra
            // 
            this.btnContaletra.Location = new System.Drawing.Point(755, 475);
            this.btnContaletra.Name = "btnContaletra";
            this.btnContaletra.Size = new System.Drawing.Size(182, 124);
            this.btnContaletra.TabIndex = 2;
            this.btnContaletra.Text = "Conta Letras";
            this.btnContaletra.UseVisualStyleBackColor = true;
            this.btnContaletra.Click += new System.EventHandler(this.btnContaletra_Click);
            // 
            // btnLocaliza
            // 
            this.btnLocaliza.Location = new System.Drawing.Point(506, 475);
            this.btnLocaliza.Name = "btnLocaliza";
            this.btnLocaliza.Size = new System.Drawing.Size(182, 124);
            this.btnLocaliza.TabIndex = 3;
            this.btnLocaliza.Text = "Posição 1º Caracter Branco";
            this.btnLocaliza.UseVisualStyleBackColor = true;
            this.btnLocaliza.Click += new System.EventHandler(this.btnLocaliza_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(1002, 475);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(182, 124);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1372, 676);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnLocaliza);
            this.Controls.Add(this.btnContaletra);
            this.Controls.Add(this.btnContnum);
            this.Controls.Add(this.rcrtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rcrtxtFrase;
        private System.Windows.Forms.Button btnContnum;
        private System.Windows.Forms.Button btnContaletra;
        private System.Windows.Forms.Button btnLocaliza;
        private System.Windows.Forms.Button btnLimpar;
    }
}