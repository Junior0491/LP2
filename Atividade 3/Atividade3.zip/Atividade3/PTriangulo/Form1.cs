﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ValorA, ValorB, ValorC;

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ValorB) || ValorB <= 0)
            {
                MessageBox.Show("O valor é inválido");
                txtLadoC.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ValorC) || ValorC <= 0)
            {
                MessageBox.Show("O valor é inválido");
                txtLadoB.Focus();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((ValorA < (ValorB + ValorC)) && (ValorA > (Math.Abs(ValorB - ValorC))) &&
                (ValorB < (ValorA + ValorC)) && (ValorB > (Math.Abs(ValorA - ValorC))) &&
                (ValorC < (ValorA + ValorB)) && (ValorC > (Math.Abs(ValorA -ValorB))))
            {
                if ((ValorA == ValorB) && (ValorB == ValorC) && (ValorA == ValorC))
                {
                    MessageBox.Show("É um triângulo equilátero");
                }
                else if ((ValorA == ValorB) || (ValorB == ValorC) || (ValorA == ValorC))
                {
                    MessageBox.Show("É um triângulo isósceles");
                }
                else
                {
                    MessageBox.Show("É um triângulo escaleno");
                }
            }
            else
            {
                MessageBox.Show("Não é um triângulo");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            ValorA = 0;
            ValorB = 0;
            ValorC = 0;

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ValorA) || ValorA <= 0)
            {
                MessageBox.Show("O valor é inválido");
                txtLadoA.Focus();
            }
        }


    }
}
