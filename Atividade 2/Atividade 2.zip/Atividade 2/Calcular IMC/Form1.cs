﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calcular_IMC
{
    public partial class Form1 : Form
    {
        double Peso;
        double Altura;
        double IMC;

        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnFechar)
            {
                return;
            }

            if (!double.TryParse(mskbxPeso.Text, out Peso) || (Peso <= 0))
            {
                MessageBox.Show("Peso Inválido!!");
                mskbxPeso.Focus();
            }

        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if(this.ActiveControl == btnFechar)
            {
                return;
            }

            if(!double.TryParse(mskbxAltura.Text, out Altura) || (Altura <= 0))
            {
                MessageBox.Show("Altura Inválida");
                mskbxAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = Peso / (Math.Pow(Altura, 2));

            IMC = Math.Round(IMC, 1);
            mskbxIMC.Text = IMC.ToString("");

            if (IMC < 18.5)
                MessageBox.Show("Magreza");
            else if (IMC <= 24.9)
                MessageBox.Show("Normal");
            else if (IMC <= 29.9)
                MessageBox.Show("Sobrepeso");
            else if (IMC <= 39.9)
                MessageBox.Show("Obesidade");
            else
                MessageBox.Show("Obesidade Grave");


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear ();
            mskbxAltura.Clear ();
            mskbxIMC.Clear ();
            Peso = 0;
            Altura = 0;
            IMC = 0;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
