﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercício4 : Form
    {
        string nome;
        int producao;
        double salario, gratificacao, salarioBruto;
        int B = 0, C = 0, D = 0;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            txtMatricula.Text = "";
            txtProducao.Text = "";
            txtSalario.Text = "";
            txtGratificacao.Text = "";
            nome = "";
            producao = 0;
            salario = 0;
            gratificacao = 0;
            salarioBruto = 0;

        }

        public frmExercício4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            nome = txtNome.Text;
            producao = Convert.ToInt32(txtProducao.Text);
            salario = Convert.ToDouble(txtSalario.Text);
            gratificacao = Convert.ToDouble(txtGratificacao.Text);


            if (producao >= 100)
            {
                B = 1;
            }

            if (producao >= 120)
            {
                C = 1;
            }

            if (producao >= 150)
            {
                D = 1;
            }

            salarioBruto = salario + (salario * ((0.05 * B) + (0.10 * C) + (1 * D))) + gratificacao;

            if (salarioBruto > 7000)
            {
                if (producao >= 150 && gratificacao > 0)
                {
                    MessageBox.Show($"O funcionário {nome}, receberá R${salarioBruto:F2} de Salário Bruto");
                }
                else
                {
                    salarioBruto = 7000;
                    MessageBox.Show($"O funcionário {nome}, receberá R${salarioBruto:F2} de Salário Bruto");
                }
            }
            else
            {
                MessageBox.Show($"O funcionário {nome}, receberá R${salarioBruto:F2} de Salário Bruto");
            }
        }
    }
}
