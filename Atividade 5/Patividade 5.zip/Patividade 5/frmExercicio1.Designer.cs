﻿namespace Patividade5
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rcrtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnLocaliza = new System.Windows.Forms.Button();
            this.btnEncontra = new System.Windows.Forms.Button();
            this.btnRepetidas = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rcrtxtFrase
            // 
            this.rcrtxtFrase.Location = new System.Drawing.Point(429, 45);
            this.rcrtxtFrase.MaxLength = 100;
            this.rcrtxtFrase.Name = "rcrtxtFrase";
            this.rcrtxtFrase.Size = new System.Drawing.Size(565, 310);
            this.rcrtxtFrase.TabIndex = 0;
            this.rcrtxtFrase.Text = "";
            // 
            // btnLocaliza
            // 
            this.btnLocaliza.Location = new System.Drawing.Point(233, 415);
            this.btnLocaliza.Name = "btnLocaliza";
            this.btnLocaliza.Size = new System.Drawing.Size(200, 151);
            this.btnLocaliza.TabIndex = 1;
            this.btnLocaliza.Text = "O número de espaços brancos";
            this.btnLocaliza.UseVisualStyleBackColor = true;
            this.btnLocaliza.Click += new System.EventHandler(this.btnLocaliza_Click);
            // 
            // btnEncontra
            // 
            this.btnEncontra.Location = new System.Drawing.Point(480, 415);
            this.btnEncontra.Name = "btnEncontra";
            this.btnEncontra.Size = new System.Drawing.Size(200, 151);
            this.btnEncontra.TabIndex = 2;
            this.btnEncontra.Text = "O número de R";
            this.btnEncontra.UseVisualStyleBackColor = true;
            this.btnEncontra.Click += new System.EventHandler(this.btnEncontra_Click);
            // 
            // btnRepetidas
            // 
            this.btnRepetidas.Location = new System.Drawing.Point(738, 415);
            this.btnRepetidas.Name = "btnRepetidas";
            this.btnRepetidas.Size = new System.Drawing.Size(200, 151);
            this.btnRepetidas.TabIndex = 3;
            this.btnRepetidas.Text = "O número de par de letras";
            this.btnRepetidas.UseVisualStyleBackColor = true;
            this.btnRepetidas.Click += new System.EventHandler(this.btnRepetidas_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(986, 415);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(200, 151);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1339, 632);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnRepetidas);
            this.Controls.Add(this.btnEncontra);
            this.Controls.Add(this.btnLocaliza);
            this.Controls.Add(this.rcrtxtFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rcrtxtFrase;
        private System.Windows.Forms.Button btnLocaliza;
        private System.Windows.Forms.Button btnEncontra;
        private System.Windows.Forms.Button btnRepetidas;
        private System.Windows.Forms.Button btnLimpar;
    }
}