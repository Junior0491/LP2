﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercício2 : Form
    {
        int N;
        double H;


        public frmExercício2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero.Text, out N))
            {
                MessageBox.Show("Digite um número inteiro válido!");
                txtNumero.Focus();
            }
            else if (N <= 0)
            {
                MessageBox.Show("O número deve ser maior que 0!");
                txtNumero.Focus();
            }

            for (int i = 1; i <= N; i++)
            {
                H += 1.0 / i;
            }

            MessageBox.Show($"O número gerado foi {H:F2}");

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero.Clear();
            N = 0;
            H = 0;
        }
    }
}
