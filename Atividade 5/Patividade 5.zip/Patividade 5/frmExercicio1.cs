﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercicio1 : Form
    {
        int espacos = 0;
        int letrasR = 0;
        int pares = 0;

        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnLocaliza_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rcrtxtFrase.Text.Length; i++)
            {
                if (rcrtxtFrase.Text[i] == ' ')

                    espacos++;

            }

            MessageBox.Show($"A frase possui {espacos} espaços");
        }

        private void btnEncontra_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rcrtxtFrase.Text.Length; i++)
            {
                if (rcrtxtFrase.Text[i] == 'R' || rcrtxtFrase.Text[i] == 'r')

                    letrasR++;
            }

            MessageBox.Show($"A frase possui {letrasR} letras R");

        }

        private void btnRepetidas_Click(object sender, EventArgs e)
        {

            for (int i = 0; i < rcrtxtFrase.Text.Length - 1; i++)
            {
                if (i < rcrtxtFrase.Text.Length && rcrtxtFrase.Text[i] == rcrtxtFrase.Text[i + 1])

                    pares++;
            }

            MessageBox.Show($"A frase possui {pares} pares de letras");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rcrtxtFrase.Clear();
            espacos = 0;
            letrasR = 0;
            pares = 0;

        }
    }
}
