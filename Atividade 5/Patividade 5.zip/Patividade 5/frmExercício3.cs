﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade5
{
    public partial class frmExercício3 : Form
    {
        string frase, invertida = "", limpo = "";

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtFrase.Text = "";
            frase = "";
            invertida = "";
            limpo = "";
        }

        public frmExercício3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            frase = txtFrase.Text.ToUpper();

            for (int i = 0; i < frase.Length; i++)
            {
                if (frase[i] != ' ')
                {
                    limpo += frase[i];
                }
            }
            for (int i = limpo.Length - 1; i >= 0; i--)
            {
                invertida += limpo[i];
            }
            if (limpo == invertida)
            {
                MessageBox.Show("É um palíndromo!");
            }
            else
            {
                MessageBox.Show("Não é um palíndromo.");
            }

        }
    }
}
